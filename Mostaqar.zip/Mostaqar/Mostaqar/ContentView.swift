//
//  ContentView.swift
//  Mostaqar
//
//  Created by Jonathan Flintham on 12/11/2024.
//

import SwiftUI
import SwiftData
import MapKit

struct Marker {
    let title: String
    let coordinate: CLLocationCoordinate2D
}

struct ContentView: View {

    let markers: [Marker]
    
    @State private var searchText = ""
    
    var body: some View {
        VStack {
            HStack {
                Text("Mostaqar")
                    .font(.title)
                
                Spacer()
                
                Button {
                    // action
                } label: {
                    Image(systemName: "magnifyingglass")
                }
                
                Spacer()
                    .frame(width: 16)
                
                Button {
                    // action
                } label: {
                    Image(systemName: "bell")
                }
            }
            .padding(.horizontal, 32)
//            
//            Map {
//                ForEach(markers, id: \.title) { marker in
//                    Marker(title: marker.title, coordinate: marker.coordinate)
//                }
//            }
            
            ScrollView {
                
                Text("Connect Here")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                ForEach(markers, id: \.title) { marker in
                    Text(marker.title)
                }
                
            }
            .searchable(text: $searchText)
        }
        
        .accentColor(.teal)
    }
}

#Preview {
    ContentView(markers: [
        .init(title: "Place 1", coordinate: .init(latitude: 500, longitude: 100))
        
    ])
        .modelContainer(for: Item.self, inMemory: true)
}
